AI ASISTEN YOSEP - PROYEK ANDROID

Ini adalah proyek sumber Android (WebView) yang membungkus aplikasi HTML AI Asisten Yosep menjadi aplikasi Android.
File ini BELUM APK yang terpasang. APK debug dapat dibuat dengan Gradle atau GitHub Actions.

CARA BUILD OTOMATIS (bisa melalui browser HP, gratis untuk repo publik):
1. Buat repository baru di GitHub dan pilih Public.
2. Upload seluruh isi folder proyek ini (jangan upload folder pembungkus AI_Asisten_Yosep_Android, tetapi semua isi di dalamnya).
3. Buka tab Actions, pilih workflow "Build AI Asisten Yosep APK".
4. Tekan Run workflow dan tunggu selesai.
5. Buka hasil workflow, bagian Artifacts, lalu unduh AI-Asisten-Yosep-debug-apk.zip.
6. Ekstrak ZIP, lalu pasang app-debug.apk di Android. Izinkan instalasi dari sumber ini jika Android memintanya.

CATATAN:
- APK ini membungkus fitur HTML yang tersedia. Generator teks masih berbasis template lokal, bukan AI online.
- Belum ada integrasi suara penuh, pembuat gambar/video asli, background service, atau posting Facebook otomatis.
- Jangan memasukkan Meta App Secret atau token ke aplikasi Android; rahasia harus disimpan di backend.
